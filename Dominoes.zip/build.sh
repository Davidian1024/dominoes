zip -r Dominoes *
